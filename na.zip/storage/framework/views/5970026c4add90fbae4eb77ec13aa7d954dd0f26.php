<?php $__env->startSection('title','title_description'); ?>
<?php $__env->startSection('description','title_description'); ?>
<?php $__env->startSection('keywords','title_keywords'); ?>

<?php $dashboard_="active";$user_="";$_category_="";$page_="";$article_="" ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(url('/css/user/info_list.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="breadcrumb container">
    <a href="<?php echo e(url('/user/index')); ?>">首页</a>
        <i class="fa fa-angle-right" aria-hidden="true"></i>
    <a href="<?php echo e(url('/user/index')); ?>">用户中心</a>
        <i class="fa fa-angle-right" aria-hidden="true"></i>
    <span>信息管理</span>
</div>

<div class="main_wrap container">

	<div class="content_wrap">
		<div class="main_wrap">
			main
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>