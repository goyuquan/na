<div class="header">
    <a href="#top_bar" id="open_nav" class="menu_bar open">
        <i class="fa fa-bars"></i>
    </a>
    <div id="top_bar" class="top_bar">
        <a href="#open_nav" class="menu_bar close">
            <i class="fa fa-arrow-up"></i>
        </a>
        <div class="container">
            <div class="top_nav">
                <a href="<?php echo e(url('/')); ?>">首页</a>
                <a href="<?php echo e(url('/admin')); ?>">控制台</a>
                <a href="<?php echo e(url('/admin/users/')); ?>">用户</a>
                <a href="<?php echo e(url('/admin/categories')); ?>">分类</a>
                <a href="<?php echo e(url('/admin/pages')); ?>">页面</a>
                <a href="<?php echo e(url('/admin/articles')); ?>">文章</a>

                <?php if(Auth::guest()): ?>
                <a href="<?php echo e(url('/login')); ?>">登陆</a>
                <a href="<?php echo e(url('/register')); ?>">注册</a>
                <?php else: ?>
                <a href="/user/index"> <?php echo e(Auth::user()->name); ?> </a>
                <a href="<?php echo e(url('/logout')); ?>" class="item"><i class="fa fa-btn fa-sign-out"></i>退出</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="head">
        <div class="container">
            <a href="<?php echo e(url('/')); ?>" class="logo">
                <img src="<?php echo e(url('img/new-logo.gif')); ?>" />
            </a>
            <ul>
                <li><a class="<?php echo e($dashboard_); ?>" href="<?php echo e(url('/admin')); ?>">控制台</a></li>
                <li><a class="<?php echo e($user_); ?>" href="<?php echo e(url('/admin/users/')); ?>">用户</a></li>
                <li><a class="<?php echo e($_category_); ?>" href="<?php echo e(url('/admin/categories')); ?>">分类</a></li>
                <li><a class="<?php echo e($page_); ?>" href="<?php echo e(url('/admin/pages')); ?>">页面</a></li>
                <li><a class="<?php echo e($article_); ?>" href="<?php echo e(url('/admin/articles')); ?>">文章</a></li>
            </ul>
        </div>
    </div>
</div>
