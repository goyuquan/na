<?php $__env->startSection('title','创建'); ?>
<?php $__env->startSection('description','title_description'); ?>
<?php $__env->startSection('keywords','title_keywords'); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="/css/admin/table.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="breadcrumb container">
    <a href="<?php echo e(url('/admin/index')); ?>">后台首页</a>
        <i class="fa fa-angle-right" aria-hidden="true"></i>
    <a href="<?php echo e(url('/admin/index')); ?>">文章管理</a>
        <i class="fa fa-angle-right" aria-hidden="true"></i>
    <span>文章管理</span>
</div>

<div class="main_wrap container">
    <div class="content_wrap">
        <?php if(count($articles) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>标题</th>
                            <th>缩略图</th>
                            <th>发布时间</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($articles as $article): ?>
                        <tr>
                            <td><?php echo e($article->id); ?></td>
                            <td><a href="/article/<?php echo e($article->id); ?>"> <?php echo e(str_limit($article->title,50)); ?> </a></td>
                            <td><?php echo e(substr($article->published_at,1,10)); ?></td>
                            <td>
                                <a href="/admin/article/<?php echo e($article->id); ?>/edit">编辑 </a>
                                <a href="/admin/article/<?php echo e($article->id); ?>/destroy" class="del">删除 </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php echo e($articles->links()); ?>

        <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(url('/js/jquery-1.12.3.min.js')); ?>"></script>
<script type="text/javascript">
$(".del").click(function(e){
    var r=confirm("确认删除");
    if (r==false) {
        e.preventDefault();
    }
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>