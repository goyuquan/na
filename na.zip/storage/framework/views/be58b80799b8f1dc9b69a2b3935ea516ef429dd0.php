<div class="footer">
    <div class="container">
        <div class="links">
            <!-- <ul>
                <li><a href="#">about us</a></li>
                <li><a href="#">about us</a></li>
                <li><a href="#">about us</a></li>
                <li><a href="#">about us</a></li>
                <li><a href="#">about us</a></li>
            </ul> -->
        </div>
        <div class="about">
            <h2 class="title">宁安信息网——宁安本地服务信息网站</h2>
            <p>
                宁安信息网,宁安本地服务信息网站,为你提供招聘信息、房产、生意转让、二手物品、车辆、求职招聘、生活服务、商务服务、教育培训等海量分类信息,充分满足您免费查看/发布信息的需求。
            </p>
            <p>
                声明：本站所有内容均由网友自行上传，不保证来源合法性和真实性，请自行辨别，接受违规举报。
            </p>
            <address class="address">
                <strong>宁安信息网</strong><br>
                <abbr title="Phone">广告咨询电话:</abbr> 13585554741<br>
                <a href="mailto:#">违规内容举报：1939837776@qq.com</a>
            </address>

        </div>
        <p class="copyright">
            版权所有：© 2016宁安信息网&nbsp;沪ICP备13032210号
        </p>
    </div>
</div>
