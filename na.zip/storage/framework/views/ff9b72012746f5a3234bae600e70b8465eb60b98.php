<?php $__env->startSection('title','创建'); ?>
<?php $__env->startSection('description','title_description'); ?>
<?php $__env->startSection('keywords','title_keywords'); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="/css/upload.css">
<link rel="stylesheet" href="/css/user/create.css">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('common.thumbnail', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>

<div class="breadcrumb container">
    <a href="<?php echo e(url('/user/index')); ?>">宁安信息网</a>
        <i class="fa fa-angle-right" aria-hidden="true"></i>
    <a href="<?php echo e(url('/user/index')); ?>">用户中心</a>
        <i class="fa fa-angle-right" aria-hidden="true"></i>
    <span>信息发布</span>
</div>

<div class="main_wrap container">
    <?php echo $__env->make('user.layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="content_wrap">
		<form id="create" method="POST" action="<?php echo e(url('/user/info/create/')); ?>">
			<input type="hidden" name="category_id" value="<?php echo e($category->id); ?>">
			<?php echo csrf_field(); ?>

			<section>
				<label for="title">标题</label>
				<input type="text" name="title">
			</section>
			<section>
				<label for="text">正文</label>
				<textarea name="text" rows="10" cols="60"></textarea>
			</section>
			<?php if(Auth::User()->role > 1): ?>
			<section>
				<label for="phone">电话号码</label>
				<input type="text" name="phone" value="<?php echo e(Auth::user()->phone); ?>">
			</section>
			<section>
				<label for="publish_at">发布时间</label>
				<input type="date" name="publish_at">
			</section>
			<?php endif; ?>
			<section class="thumb_wrap">
				<label for="thumbnail">缩略图</label>
				<button type="button" id="thumbnail_bt">上传缩略图</button>
			</section>
			<section class="photo_wrap">
				<label for="photos">图片</label>
				<input type="hidden" id="photos_sha1" name="photos_sha1" value="<?php echo e(sha1(time())); ?>">
				<button type="button" id="photos_bt">上传图片</button>
			</section>


			<input type="submit" value="提交">
		</form>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(url('/js/jquery-1.12.3.min.js')); ?>"></script>
<script src="<?php echo e(url('/js/thumbnail.js')); ?>"></script>
<script src="<?php echo e(url('/js/dropzone.min.js')); ?>"></script>
<script type="text/javascript">
$(function(){

    $("#my-awesome-dropzone").dropzone({
        url: "/upload/photos/"+$("#photos_sha1").val(),
        parallelUploads: 1,
        maxFilesize: 0.5,
		maxFiles:10,
        thumbnailWidth: 100,
        thumbnailHeight: 100,
        dictFileTooBig:"文件太大了",
        dragenter:function(){
			$("#my-awesome-dropzone").css("border-color","#eea236");
		},
		dragleave:function(){
			$("#my-awesome-dropzone").css("border-color","#398439");
		}
     });

	var validate = $("#create").validate({
	    debug: true, //调试模式取消submit的默认提交功能
	    submitHandler: function(form){   //表单提交句柄,为一回调函数,带一个参数：form
	        form.submit();   //提交表单
	    },

		rules : {
			title : {
				required : true,
				minlength : 4,
				maxlength : 30
			},
			text : {
				required : true,
				minlength : 10,
				maxlength : 1000
			}
		},

		messages : {
			title : {
				required : '标题不能为空',
				minlength : '标题最长不能小于4位',
				maxlength : '标题最长不能大于30'
			},
			text : {
				required : '正文内容不能为空',
				minlength : '正文内容最长不能小于10',
				maxlength : '正文内容最长不能大于1000'
			}
		},
	});
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>