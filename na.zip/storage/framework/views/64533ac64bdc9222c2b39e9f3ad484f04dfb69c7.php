<?php $__env->startSection('title','title_description'); ?>
<?php $__env->startSection('description','title_description'); ?>
<?php $__env->startSection('keywords','title_keywords'); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(url('/css/categories.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="breadcrumb container">
    <a href="<?php echo e(url('/')); ?>">宁安信息网</a>
        <i class="fa fa-angle-right" aria-hidden="true"></i>
    <span>创建新信息-选择分类</span>
</div>

<div class="category container">
    <div class="head">
        <h2>选择分类</h2>
    </div>
    <div class="column">

        <h3><?php echo e($categories[0]->name); ?></h3>
        <?php if(count($type[0]) > 0): ?>
        <ul>
            <?php foreach($type[0] as $cate): ?>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="<?php echo e(url('/user/info/create/category/'.$cate->id)); ?>"><?php echo e($cate->name); ?></a>
            </li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>

        <h3><?php echo e($categories[1]->name); ?></h3>
        <?php if( isset($type[1]) && count($type[1]) > 0): ?>
        <ul>
            <?php foreach($type[1] as $cate): ?>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="<?php echo e(url('/user/info/create/category/'.$cate->id)); ?>"><?php echo e($cate->name); ?></a>
            </li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>

        <h3><?php echo e($categories[2]->name); ?></h3>
        <?php if( isset($type[2]) && count($type[2]) > 0): ?>
        <ul>
            <?php foreach($type[2] as $cate): ?>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="<?php echo e(url('/user/info/create/category/'.$cate->id)); ?>"><?php echo e($cate->name); ?></a>
            </li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>

    </div>
    <div class="column">
        <h3>mobile phone</h3>
        <ul>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="#">胆固醇</a>
            </li>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="#">胆固醇</a>
            </li>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="#">胆固醇</a>
            </li>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="#">胆固醇</a>
            </li>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="#">胆固醇</a>
            </li>
        </ul>
        <h3><a href="#">老中青</a></h3>
        <ul>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="#">胆固醇</a>
            </li>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="#">温暖</a>
            </li>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="#">噢民</a>
            </li>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="#">党中央</a>
            </li>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="#">一缺抽</a>
            </li>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="#">的脱掉</a>
            </li>
        </ul>
    </div>
    <div class="column">
        <h3>mobile phone</h3>
        <ul>
            <li>
                <a href="#">mobile phhone</a>
            </li>
        </ul>
    </div>
    <div class="column">
        <h3>mobile phone</h3>
        <ul>
            <li>
                <a href="#">mobile phhone</a>
            </li>
        </ul>
    </div>
    <div class="column">
        <h3>mobile phone</h3>
        <ul>
            <li>
                <a href="#">mobile phhone</a>
            </li>
        </ul>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>