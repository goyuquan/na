<?php $__env->startSection('title',$category->name.'_'.$parent_category->name.'_宁安信息网'); ?>
<?php $__env->startSection('description','title_description'); ?>
<?php $__env->startSection('keywords','title_keywords'); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(url('/css/category.css')); ?>" >
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="breadcrumb container">
    <a href="<?php echo e(url('/')); ?>">宁安信息网</a>
        <i class="fa fa-angle-right" aria-hidden="true"></i>
    <a href="<?php echo e(url('/categories')); ?>">分类信息</a>
        <i class="fa fa-angle-right" aria-hidden="true"></i>
    <span><?php echo e($category->name); ?></span>
    &nbsp;<button type="button" name="返回" onclick="history.go(-1)">返回</button>
    <?php $category_active = $category->name ?>
</div>

<div class="main_wrap container">

    <div class="category">
        <h3>分类菜单</h3>

        <?php echo $__env->make('info.categories.sidebar_catelist', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>
    <div class="content">
        <div class="headbar">
            headbar
        </div>

        <?php if(count($infos) > 0): ?>
        <ul class="list">
            <?php foreach( $infos as $info ): ?>
            <li>
                <span class="date"><?php echo e(substr($info->publish_at,0,10)); ?></span>
                <h4><a href="<?php echo e(url('/info/'.$info->id)); ?>"><?php echo e(str_limit($info->title,30)); ?></a></h4>
                <span class="price">
                    <?php if(isset(json_decode($info->content)->price)){
                        echo "￥".json_decode($info->content)->price;
                    } else {
                        echo "面议";
                    }
                    ?>
                </span>
                <span class="phone"><?php echo e(json_decode($info->content)->phone); ?></span>
                <p> <?php echo e(str_limit($info->text,100)); ?> </p>
            </li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>
        <?php echo e($infos->links()); ?>


    </div>

</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    $(function(){
        $(".category > ul > li").click(function(){
            $(this).find('ul').slideToggle('fast');
        });
        $(".category li").click(function(e){
            e.stopPropagation();
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>