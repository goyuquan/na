<?php $__env->startSection('content'); ?>

<?php if(count($pagess) > 0): ?>
<ul>
    <?php foreach( $pagess as $page ): ?>
        <li><span><?php echo e($page->name); ?></span>
            <span><?php echo e($page->alias); ?></span>
            <?php if( !App\Category::where('parent_id',$page->id)->get()->isEmpty() ): ?>

                <ul> <?php foreach( $pages as $page_ ): ?>
                    <?php if($page_->parent_id === $page->id): ?>
                        <li>
                            <b> <?php echo e($page_->name); ?> </b>
                            <span> <?php echo e($page_->alias); ?> </span>
                         </li>
                    <?php endif; ?>
                <?php endforeach; ?> </ul>

            <?php endif; ?>
        </li>
    <?php endforeach; ?>
</ul>
<?php endif; ?>

<form id="page" method="POST" action="<?php echo e(url('/admin/page/update/'.$name->id)); ?>">
	<?php echo csrf_field(); ?>

	<section>
		<label for="name">分类名称</label>
		<input type="text" name="name" id="name" value="<?php echo e($name->name); ?>">
		<?php if($errors->has('name')): ?>
			<strong><?php echo e($errors->first('name')); ?></strong>
		<?php endif; ?>
	</section>
    <section>
		<label for="alias">别名</label>
		<input type="text" name="alias" id="alias" value="<?php echo e($name->alias); ?>">
		<?php if($errors->has('alias')): ?>
			<strong><?php echo e($errors->first('alias')); ?></strong>
		<?php endif; ?>
	</section>
    <?php if(count($pages) > 0): ?>
	<section>
		<label for="parent">父页面</label>
        <select name="parent" id="parent">
            <option value="0">无</option>
            <?php foreach( $pages as $page ): ?>
            <option value="<?php echo e($page->id); ?>"
                <?php if($page->id == $name->parent_id): ?>
                 selected="selected"
                 <?php endif; ?>
                ><?php echo e($page->name); ?></option>
            <?php endforeach; ?>
        </select>
	</section>
    <?php endif; ?>

	<input type="submit" value="修改">
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="http://cdn.bootcss.com/jquery-validate/1.15.0/jquery.validate.min.js"></script>
<script src="<?php echo e(url('/js/additional-methods.js')); ?>"></script>
<script type="text/javascript">
$(function(){
	var validate = $("#page").validate({

	    submitHandler: function(form){   //表单提交句柄,为一回调函数,带一个参数：form
	        form.submit();   //提交表单
	    },

		rules : {
			name : {
				required : true,
				minlength : 1,
				maxlength : 20
			},
            alias : {
				required : true,
				minlength : 2,
				maxlength : 20
			}
		},

		messages : {
			name : {
				required : '名称不能为空',
				max : '名称最长不能大于20'
			},
            alias : {
				required : '别名不能为空',
				min : '别名最长不能小于2'
				max : '别名最长不能大于20'
			}
		}

	});
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>