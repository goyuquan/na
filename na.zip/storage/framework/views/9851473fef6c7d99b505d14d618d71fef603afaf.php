<?php $__env->startSection('title',$article->title.'_宁安新闻_宁安信息网'); ?>
<?php $__env->startSection('description',$article->title); ?>
<?php $__env->startSection('keywords',$article->title); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(url('/css/show.css')); ?>" >
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="breadcrumb container">
    <a href="<?php echo e(url('/')); ?>">宁安信息网</a>
    <i class="fa fa-angle-right" aria-hidden="true"></i>
    <a href="<?php echo e(url('/articles')); ?>">宁安新闻</a>
    <i class="fa fa-angle-right" aria-hidden="true"></i>
    <span><?php echo e($article->title); ?></span>
    &nbsp;<button type="button" name="返回" onclick="history.go(-1)">返回</button>
</div>

<div class="main_wrap container">
    <div class="sidebar">
        <h3>分类菜单</h3>
    </div>
    <div class="content">
        <h1><?php echo e($article->title); ?></h1>
        <div class="sub_info">
            <span>发布日期:&nbsp;<?php echo e(substr($article->publish_at,0,10)); ?></span>
        </div>
        <div class="text_wrap">
            <div class="text_ad">
                text_ad
            </div>
            <?php echo(html_entity_decode($article->text, ENT_QUOTES, 'UTF-8')); ?>
        </div>

    </div>
</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>