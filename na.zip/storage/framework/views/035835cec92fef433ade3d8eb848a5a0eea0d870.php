<?php $__env->startSection('title','用户注册_宁安信息网'); ?>
<?php $__env->startSection('description','宁安信息网信息用户注册,宁安本地服务网站,为你提供招聘信息、房产、生意转让、二手物品、车辆、求职招聘、生活服务、商务服务、教育培训等海量分类信息,充分满足您免费查看/发布信息的需求。'); ?>
<?php $__env->startSection('keywords','宁安信息网用户注册,宁安招聘,宁安房产,宁安吧,宁安论坛,231084,157400,宁安网,宁安免费发布信息'); ?>

<?php $__env->startSection('style'); ?>
	<link rel="stylesheet" href="<?php echo e(url('/css/login.css')); ?>" />
	<style media="screen">
		.add_a {
			color: #fff;
		}
		.main_wrap .main {
			min-height: 380px;
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="main_wrap container">
	<div class="form">

		<div class="register">
			<h1>注&nbsp;册</h1>
			<form id="register" method="POST" action="<?php echo e(url('/register')); ?>">
				<?php echo csrf_field(); ?>

				<section>
					<input type="text" name="name" value="<?php echo e(old('name')); ?>" placeholder="用户名">
					<?php if($errors->has('name')): ?>
					<strong><?php echo e($errors->first('name')); ?></strong>
					<?php endif; ?>
				</section>
				<section>
					<input type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="Email">
					<?php if($errors->has('email')): ?>
					<strong><?php echo e($errors->first('email')); ?></strong>
					<?php endif; ?>
				</section>
				<section>
					<input type="text" name="phone" value="<?php echo e(old('phone')); ?>" placeholder="手机号">
					<?php if($errors->has('phone')): ?>
					<strong><?php echo e($errors->first('phone')); ?></strong>
					<?php endif; ?>
				</section>
				<section>
					<input type="password" name="password" id="password" value="<?php echo e(old('password')); ?>" placeholder="密码">
					<?php if($errors->has('password')): ?>
					<strong><?php echo e($errors->first('password')); ?></strong>
					<?php endif; ?>
				</section>
				<section>
					<input type="password" name="password_confirmation" placeholder="重复密码">
					<?php if($errors->has('password_confirmation')): ?>
					<strong><?php echo e($errors->first('password_confirmation')); ?></strong>
					<?php endif; ?>
				</section>
				<section>
					<input type="hidden" id="distinguished" name="distinguished" value="abcedfg" >
					<input type="text" name="distinguish" placeholder="填写:abcedfg" >
				</section>

				<input type="submit" value="注&nbsp;册"><br><br>
				<a class="add_a" href="<?php echo e(url('/login')); ?>">已有帐号？登录</a>
			</form>

		</div>
	</div>
	<div class="main">
		<h2>宁安本地服务信息网站</h2>

		<ul>
			<!-- <li>
				<div class="icon">
					<img src="<?php echo e(url('/img/icon_3456464653364.png')); ?>" />
				</div>
				<span>Lorem ipsum dolor sit amet, consectetuipsum dolor sit amet, consectetuipsum dolor sit amet, consectetur</span>
			</li>
			<li>
				<div class="icon">
					<img src="<?php echo e(url('/img/icon_34564365464.png')); ?>" />
				</div>
				<span>Lorem ipsum dolor sit amet, consectetuipsum dolor sit amet, consectetuipsum dolor sit amet, consectetur</span>
			</li> -->
			<li>
				<div class="icon">
					<img src="<?php echo e(url('/img/icon_34564364.png')); ?>" />
				</div>
				<span>响应式设计，电脑、平板电脑、手机显示更合理，可以智能地根据用户行为以及使用的设备环境
					（系统平台、屏幕尺寸、屏幕定向等）进行相对应的布局。。</span>			</li>
		</ul>
	</div>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(url('/js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(url('/js/validate-phone-additional-methods.js')); ?>"></script>
<script type="text/javascript">
$(function(){

	var validate = $("#register").validate({
		debug: true, //调试模式取消submit的默认提交功能
		submitHandler: function(form){   //表单提交句柄,为一回调函数,带一个参数：form
			form.submit();   //提交表单
		},

		rules : {
			name : {
				required : true,
				minlength : 2,
				maxlength : 20
			},
			email : {
				email : true
			},
			phone : {
				required : true,
				isMobile : true
			},
			password : {
				required : true,
				minlength : 6,
				maxlength : 50
			},
			password_confirmation : {
				required : true,
				equalTo : '#password'
			},
			distinguish : {
				equalTo : '#distinguished',
				required : true
			}
		},

		messages : {
			name : {
				required : '请输入用户名'
			},
			email : {
				required : '请输入 email',
				email : 'email 格式不正确'
			},
			phone : {
				required : '手机号码必须填写',
				isMobile : '手机号码不正确'
			},
			password : {
				required : '请输入密码',
				minlength : '密码长度不能小于6位',
				maxlength : '密码长度不能大于50位'
			},
			password_confirmation : {
				required : '重复密码不能为空',
				equalTo : '两次输入密码不一致'
			},
			distinguish : {
				required : '输入abcedfg',
				equalTo : '输入abcedfg'
			}
		},
	});
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>