<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>_description">
	<meta name="keywords" content="<?php echo $__env->yieldContent('keywords'); ?>_keywords">
    <link href="<?php echo e(url('/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(url('/css/admin/common.css')); ?>"/>
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body>
    <?php echo $__env->make('admin.layouts.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>
