<ul>
    <?php for($i = 0; $i < count($categories); $i++): ?>

        <li>
            <h4><?php echo e($categories[$i]->name); ?> </h4>
            <?php if( isset($type[$i]) && count($type[$i]) > 0): ?>
            <ul>
                <?php foreach($type[$i] as $cate): ?>
                <li <?php echo e($category_active == $cate->name ? "class=active" : ""); ?>>
                    <a href="<?php echo e(url('/infos/category/'.$cate->id)); ?>"><?php echo e($cate->name); ?></a>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
        </li>
    <?php endfor; ?>
</ul>
