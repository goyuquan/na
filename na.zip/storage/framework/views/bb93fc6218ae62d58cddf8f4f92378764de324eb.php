<?php $__env->startSection('title','创建'); ?>
<?php $__env->startSection('description','title_description'); ?>
<?php $__env->startSection('keywords','title_keywords'); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="/css/upload.css">
<link rel="stylesheet" href="/css/user/edit.css">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('common.thumbnail', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>

<div class="breadcrumb container">
    <a href="<?php echo e(url('/user/index')); ?>">宁安信息网</a>
        <i class="fa fa-angle-right" aria-hidden="true"></i>
    <a href="<?php echo e(url('/user/index')); ?>">用户中心</a>
        <i class="fa fa-angle-right" aria-hidden="true"></i>
    <span>信息发布</span>
</div>

<div class="main_wrap container">
    <?php echo $__env->make('user.layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="content_wrap">
		<form id="edit" method="POST" action="<?php echo e(url('/user/info/update/'.$info->id)); ?>">
			<input type="hidden" name="page" value="<?php echo e($info->id); ?>">
			<?php echo csrf_field(); ?>

			<section>
				<label for="title">标题</label>
				<input type="text" name="title" value="<?php echo e($info->title); ?>">
				<?php if($errors->has('title')): ?>
					<strong><?php echo e($errors->first('title')); ?></strong>
				<?php endif; ?>
			</section>
			<section>
				<label for="text">描述</label>
				<textarea type="text" name="text"><?php echo e($info->text); ?></textarea>
				<?php if($errors->has('text')): ?>
					<strong><?php echo e($errors->first('text')); ?></strong>
				<?php endif; ?>
			</section>
			<section>
				<?php if(count($categoriess) > 0): ?>
				<label for="parent_category">父类别</label>
				<select name="parent_category" id="parent_category">
					<?php foreach( $categoriess as $category ): ?>
					<option value="<?php echo e($category->id); ?>"
						<?php if($category->id == $current_category->parent_id): ?>
						 selected="selected"
						 <?php endif; ?>
						><?php echo e($category->name); ?></option>
					<?php endforeach; ?>
				</select>
				<?php endif; ?>
                &nbsp;&nbsp;
				<?php if(count($categories) > 0): ?>
				<label for="category">类别</label>
				<select name="category_id" id="category">
					<?php foreach( $categories as $category ): ?>
					<option value="<?php echo e($category->id); ?>" data-parent="<?php echo e($category->parent_id); ?>"
						<?php if($category->id == $current_category->id): ?>
						selected="selected"
						<?php endif; ?>
						><?php echo e($category->name); ?></option>
					<?php endforeach; ?>
				</select>
				<?php endif; ?>
			</section>
            <section>
				<label for="phone">电话号码</label>
				<input type="text" name="phone" value="<?php echo e(Auth::user()->phone); ?>">
			</section>
			<section class="thumb_wrap">
				<label for="thumbnail">缩略图</label>
				<?php if(isset($content->thumbnail)): ?>
				<img id="thumbnail" name="<?php echo e($content->thumbnail); ?>" src="<?php echo e(url('/uploads/thumbnails/'.$content->thumbnail)); ?>" />
				<button type="button" id="delete_thumb">删除</button>
				<?php else: ?>
				<button type="button" id="thumbnail_bt">上传缩略图</button>
				<?php endif; ?>
			</section>
			<section class="photo_wrap">
				<label for="photos">图片</label>
					<?php if($photos && count($photos) > 0): ?>
						<?php foreach($photos as $photo): ?>
						<img src="<?php echo e(url('uploads/thumbnails/'.$photo->name)); ?>" />
						<?php endforeach; ?>
						<button type="button" id="delete_photos">删除</button>
					<?php else: ?>
						<button type="button" id="photos_bt">上传图片</button>
					<?php endif; ?>
				<input type="hidden" id="photos_sha1" name="photos_sha1" value="<?php echo e(isset($content->photos_sha1) ? $content->photos_sha1 : sha1(time())); ?>">
			</section>

			<input type="submit" value="修改">
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(url('/js/jquery-1.12.3.min.js')); ?>"></script>
<?php echo $__env->make('user.info.edit.category_select', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script src="<?php echo e(url('/js/thumbnail.js')); ?>"></script>
<script src="<?php echo e(url('/js/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(url('/js/dropzone.min.js')); ?>"></script>
<script type="text/javascript">
$(function(){

	$('#delete_thumb').click(function(){
		var src = $("#thumbnail").attr("name");
		var page = $("input[name='page']").val();
		$.ajax({
			type:"GET",
			url:"/delete/page/"+page+"/thumbnail/"+src,
			success:function(data){
				console.log(data);
				$("#delete_thumb").after('<label for="thumbnail">缩略图</label> <button type="button" id="thumbnail_bt">上传缩略图</button>')
				$("#delete_thumb,#thumbnail").remove();
			}
		});
	});

	$('#delete_photos').click(function(){
		var page = $("input[name='page']").val();
		var sha1 = $("#photos_sha1").val();
		$.ajax({
			type:"GET",
			url:"/delete/page/"+page+"/photos/"+sha1,
			success:function(data){
				console.log(data);
				$("#delete_photos").after('<button type="button" id="photos_bt">上传图片</button>');
				$("#delete_photos,.photo_wrap img").remove();
			}
		});
	});

	$("#my-awesome-dropzone").dropzone({
        url: "/upload/photos/"+$("#photos_sha1").val(),
        parallelUploads: 1,
        maxFilesize: 0.5,
		maxFiles:10,
        thumbnailWidth: 100,
        thumbnailHeight: 100,
        dictFileTooBig:"文件太大了",
        dragenter:function(){
			$("#my-awesome-dropzone").css("border-color","#eea236");
		},
		dragleave:function(){
			$("#my-awesome-dropzone").css("border-color","#398439");
		}
     });

	var validate = $("#edit").validate({
	    submitHandler: function(form){   //表单提交句柄,为一回调函数,带一个参数：form
	        form.submit();   //提交表单
	    },
		rules : {
			title : {
				required : true,
				minlength : 5,
				maxlength : 50
			},
            text : {
				required : true,
				minlength : 10,
				maxlength : 1000
			}
		},
		messages : {
			title : {
				required : '标题不能为空',
				minlength : '标题最长不能小于5',
				maxlength : '标题最长不能大于50'
			},
            text : {
				required : '内容不能为空',
				minlength : '内容最长不能小于10',
				maxlength : '内容最长不能大于1000'
			}
		}
	});

});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>