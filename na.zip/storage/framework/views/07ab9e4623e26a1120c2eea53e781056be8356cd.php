<?php $__env->startSection('content'); ?>

    <?php if(count($users) > 0): ?>
    <table>
        <thead>
            <th> ID </th>
            <th> 用户名 </th>
            <th> email </th>
            <th> 手机号 </th>
            <th> 注册时间 </th>
            <th> 更新时间 </th>
        </thead>
        <tbody>
        <?php foreach($users as $user): ?>
        <tr>
            <td> <?php echo e($user->id); ?> </td>
            <td> <?php echo e($user->name); ?> </td>
            <td> <?php echo e($user->email); ?> </td>
            <td> <?php echo e($user->phone); ?> </td>
            <td> <?php echo e(substr($user->created_at,0,10)); ?> </td>
            <td> <?php echo e(substr($user->updated_at,0,10)); ?> </td>
            <td>
                <a href="<?php echo e(url('/admin/user/edit/'.$user->id)); ?>">编辑</a>
                <a class="del" href="<?php echo e(url('/admin/user/delete/'.$user->id)); ?>">删除</a>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
    <div class="pagenation">
        <?php echo e($users->links()); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
$(function(){
    $(".del").click(function(e){
        var r=confirm("确认删除");
        if (r==false) {
            e.preventDefault();
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>