<?php $__env->startSection('title','title_description'); ?>
<?php $__env->startSection('description','title_description'); ?>
<?php $__env->startSection('keywords','title_keywords'); ?>

<?php $__env->startSection('content'); ?>
<h1>用户首页</h1>
<ul>
    <li><a href="/user/infos">发布的内容</a></li>
</ul>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>