<?php $__env->startSection('title','title_description'); ?>
<?php $__env->startSection('description','title_description'); ?>
<?php $__env->startSection('keywords','title_keywords'); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(url('/css/user/info_list.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="breadcrumb container">
    <a href="<?php echo e(url('/user/index')); ?>">宁安信息网</a>
        <i class="fa fa-angle-right" aria-hidden="true"></i>
    <a href="<?php echo e(url('/user/index')); ?>">用户中心</a>
        <i class="fa fa-angle-right" aria-hidden="true"></i>
    <span>信息管理</span>
</div>

<div class="main_wrap container">
    <?php echo $__env->make('user.layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="content_wrap">

        <a class="add" href="<?php echo e(url('/user/info/create_category')); ?>">发布新信息</a>
         <span> 用户信息每天可以刷新一次置顶 </span>

         <hr>
        <?php if(count($infos) > 0): ?>

        <table>
            <thead>
                <th> 标题 </th>
                <th> 时间 </th>
                <?php if($user->role > 4): ?>
                    <th> 用户 </th>
                <?php endif; ?>
                <th> 管理 </th>
            </thead>
            <?php foreach($infos as $info): ?>
            <tr>
                <td><?php echo e($info->title); ?></td>
                <td><?php echo e(substr($info->publish_at,0,10)); ?></td>
                <?php if($user->role > 4): ?>
                <td> <?php echo e($info->user->name); ?> </td>
                <?php endif; ?>
                <td>&nbsp;
                    <?php if( time() - strtotime($info->publish_at) > (60*60*24)): ?>
                        <a href="/user/info/refresh/<?php echo e($info->id); ?>">刷新</a>
                    <?php endif; ?>
                    <a href="/user/info/edit/<?php echo e($info->id); ?>">编辑</a>
                    <a class="del" href="/user/info/delete/<?php echo e($info->id); ?>">删除</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php endif; ?>
        <p> <?php echo e($infos->links()); ?> </p>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(url('/js/jquery-1.12.3.min.js')); ?>"></script>
<script type="text/javascript">
$(function(){

	$(".del").click(function(e){
		var r=confirm("确认删除");
		if (r==false) {
			e.preventDefault();
		}
	});

});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>