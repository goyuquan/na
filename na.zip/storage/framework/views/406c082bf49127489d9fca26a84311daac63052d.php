<?php $__env->startSection('title','分类信息_宁安信息网'); ?>
<?php $__env->startSection('description','宁安信息网分类信息,宁安本地服务网站,为你提供招聘信息、房产、生意转让、二手物品、车辆、求职招聘、生活服务、商务服务、教育培训等海量分类信息,充分满足您免费查看/发布信息的需求。'); ?>
<?php $__env->startSection('keywords','宁安分类信息,宁安招聘,宁安房产,宁安吧,宁安论坛,231084,157400,宁安网,宁安免费发布信息'); ?>

<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(url('/css/categories.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="breadcrumb container">
    <a href="<?php echo e(url('/')); ?>">宁安信息网</a>
        <i class="fa fa-angle-right" aria-hidden="true"></i>
    <span>分类信息目录</span>
</div>


<div class="category container">
    <div class="head">
        <h2>宁安分类信息目录</h2>
    </div>
    <div class="column">

        <h3><?php echo e($categories[0]->name); ?></h3>
        <?php if(count($type[0]) > 0): ?>
        <ul>
            <?php foreach($type[0] as $cate): ?>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="<?php echo e(url('/infos/category/'.$cate->id)); ?>"><?php echo e($cate->name); ?></a>
            </li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>

        <h3><?php echo e($categories[1]->name); ?></h3>
        <?php if( isset($type[1]) && count($type[1]) > 0): ?>
        <ul>
            <?php foreach($type[1] as $cate): ?>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="<?php echo e(url('/infos/category/'.$cate->id)); ?>"><?php echo e($cate->name); ?></a>
            </li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>

        <h3><?php echo e($categories[2]->name); ?></h3>
        <?php if( isset($type[2]) && count($type[2]) > 0): ?>
        <ul>
            <?php foreach($type[2] as $cate): ?>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="<?php echo e(url('/infos/category/'.$cate->id)); ?>"><?php echo e($cate->name); ?></a>
            </li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>

    </div>
    <div class="column">
        <h3>mobile phone</h3>
        <ul>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="#">胆固醇</a>
            </li>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="#">胆固醇</a>
            </li>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="#">胆固醇</a>
            </li>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="#">胆固醇</a>
            </li>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="#">胆固醇</a>
            </li>
        </ul>
        <h3><a href="#">老中青</a></h3>
        <ul>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="#">胆固醇</a>
            </li>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="#">温暖</a>
            </li>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="#">噢民</a>
            </li>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="#">党中央</a>
            </li>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="#">一缺抽</a>
            </li>
            <li>
                <i class="fa fa-angle-right" aria-hidden="true"></i>
                <a href="#">的脱掉</a>
            </li>
        </ul>
    </div>
    <div class="column">
        <h3>mobile phone</h3>
        <ul>
            <li>
                <a href="#">mobile phhone</a>
            </li>
        </ul>
    </div>
    <div class="column">
        <h3>mobile phone</h3>
        <ul>
            <li>
                <a href="#">mobile phhone</a>
            </li>
        </ul>
    </div>
    <div class="column">
        <h3>mobile phone</h3>
        <ul>
            <li>
                <a href="#">mobile phhone</a>
            </li>
        </ul>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>