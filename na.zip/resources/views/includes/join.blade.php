<div class="ui container order">
    <div class="ui center aligned basic segment">
        <h2 class="ui dividing header"><i class="users icon"></i>成为网站VIP会员浏览全部图片和视频</h2>
        <a href="/price">
            <img src="/img/T1HHFgXXVeXXXXXXXX.png" alt="" style="width:120px;margin-right:1em;" />
        </a>
        <a href="/price" class="ui green labeled icon button">加入VIP会员<i class="user icon"></i></a>
    </div>
</div>
