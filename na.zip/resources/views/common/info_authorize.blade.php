 <h2>{{$info}}</h2>
 <button type="button" name="返回" onclick="history.go(-1)">返回</button>
