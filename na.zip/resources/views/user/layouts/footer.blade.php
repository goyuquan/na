<div class="footer">
    <div class="container">
        <div class="links">
            <ul>
                <li><a href="#">about us</a></li>
                <li><a href="#">about us</a></li>
                <li><a href="#">about us</a></li>
                <li><a href="#">about us</a></li>
                <li><a href="#">about us</a></li>
            </ul>
        </div>
        <div class="about">
            <h2 class="title">困在进行哈士奇Popular Cities</h2>
            <p>
                Quikr is India’s leading classifieds platform that brings millions
                of buyers and sellers together in various categories such as cars,
                real estate, home services, jobs, mobiles,
            </p>
            <address class="address">
                <strong>Twitter, Inc.</strong><br>
                795 Folsom Ave, Suite 600<br>
                San Francisco, CA 94107<br>
                <abbr title="Phone">P:</abbr> (123) 456-7890
            </address>
            <address>
                <strong>Full Name</strong><br>
                <a href="mailto:#">first.last@example.com</a>
            </address>

        </div>
        <p class="copyright">
            Copyright © 2008 - 2016 Quikr India Private Limited
        </p>
    </div>
</div>
